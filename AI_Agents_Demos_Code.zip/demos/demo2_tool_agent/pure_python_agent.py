"""
Demo 2a — Pure Python ReAct-style agent (no external LLM needed)

This version uses a simple rule-based "brain" so you can understand
the agent loop without any API keys or local models.
"""

import re
import math
from typing import Callable, Dict, List, Tuple


# ---------- Tools ----------
def calculator(expression: str) -> str:
    """Safely evaluate a basic math expression."""
    allowed = set("0123456789+-*/().% ")
    if not all(c in allowed for c in expression):
        return "Error: invalid characters in expression"
    try:
        # Replace % with /100 for percentage
        expr = expression.replace("%", "/100")
        result = eval(expr, {"__builtins__": {}}, {"math": math})
        return str(result)
    except Exception as e:
        return f"Error: {e}"


def mock_search(query: str) -> str:
    """Tiny fake search engine with a few hard-coded facts."""
    knowledge = {
        "population of bengaluru": "The estimated population of Bengaluru (Bangalore) in 2024–25 is approximately 14 million (1.4 crore).",
        "population of bangalore": "The estimated population of Bengaluru (Bangalore) in 2024–25 is approximately 14 million (1.4 crore).",
        "capital of karnataka": "Bengaluru (Bangalore) is the capital of the Indian state of Karnataka.",
        "python creator": "Python was created by Guido van Rossum and first released in 1991.",
    }
    q = query.lower().strip()
    for key, value in knowledge.items():
        if key in q:
            return value
    return f"No information found for: {query}"


TOOLS: Dict[str, Callable[[str], str]] = {
    "calculator": calculator,
    "search": mock_search,
}


# ---------- Simple rule-based "LLM" that decides the next step ----------
def mock_llm(goal: str, history: List[str]) -> str:
    """
    Extremely simplified decision maker that produces ReAct-style steps.
    In a real agent this would be an actual LLM call.
    """
    history_text = "\n".join(history).lower()

    # If we already have a numeric answer in the last observation, finish
    if history and "observation:" in history[-1].lower():
        last_obs = history[-1]
        # Look for a pure number
        nums = re.findall(r"[-+]?\d*\.?\d+", last_obs)
        if nums and ("population" in goal.lower() or "%" in goal or "percent" in goal.lower()):
            return f"Final Answer: {nums[0]}"

    # Decide which tool to call based on the goal
    if "population" in goal.lower() and "search" not in history_text:
        return 'Thought: I need the population figure first.\nAction: search["population of Bengaluru"]'

    if ("%" in goal or "percent" in goal.lower()) and "calculator" not in history_text:
        # Extract numbers if present in history
        return 'Thought: I have the population. Now I should calculate the percentage.\nAction: calculator["0.17 * 14000000"]'

    if "fibonacci" in goal.lower() or "factorial" in goal.lower():
        return 'Thought: This is a pure calculation.\nAction: calculator["5*4*3*2*1"]'

    # Default fallback
    return "Thought: I don't know how to proceed further.\nFinal Answer: Unable to solve with available tools."


# ---------- Agent loop ----------
def run_agent(goal: str, max_steps: int = 6) -> None:
    print(f"Goal: {goal}")
    print("=" * 60)

    history: List[str] = []

    for step in range(1, max_steps + 1):
        print(f"\n--- Step {step} ---")
        decision = mock_llm(goal, history)
        print(decision)

        # Parse Action
        action_match = re.search(r'Action:\s*(\w+)\["(.+?)"\]', decision)
        if action_match:
            tool_name = action_match.group(1)
            tool_input = action_match.group(2)

            if tool_name not in TOOLS:
                observation = f"Error: unknown tool '{tool_name}'"
            else:
                observation = TOOLS[tool_name](tool_input)

            obs_line = f"Observation: {observation}"
            print(obs_line)
            history.append(decision)
            history.append(obs_line)
            continue

        # Check for Final Answer
        if "Final Answer:" in decision:
            history.append(decision)
            break

        history.append(decision)

    print("\n" + "=" * 60)
    print("Agent finished.")


if __name__ == "__main__":
    # Example 1
    run_agent("What is 17% of the population of Bengaluru?")

    print("\n\n")

    # Example 2
    run_agent("Calculate the factorial of 5")
