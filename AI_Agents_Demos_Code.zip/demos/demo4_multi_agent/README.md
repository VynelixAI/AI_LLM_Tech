# Demo 4 — Multi-Agent Sketch (CrewAI style)

## Goal
Understand multi-agent collaboration by running a simple Researcher → Writer → Critic pipeline.

## Two versions
1. **pure_python_crew.py** — Fully offline, rule-based agents (no LLM needed). Great for understanding the pattern.
2. **crewai_example.py** — Real multi-agent system using the CrewAI library + Ollama.

## Prerequisites for CrewAI version
```bash
pip install crewai crewai-tools langchain-ollama
ollama pull llama3.2
```

## How to run
```bash
python pure_python_crew.py
# or
python crewai_example.py
```
