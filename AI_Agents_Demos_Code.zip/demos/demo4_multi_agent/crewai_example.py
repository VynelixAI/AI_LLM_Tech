"""
Demo 4b — Multi-agent system with CrewAI + Ollama

Requires:
  pip install crewai crewai-tools langchain-ollama
  ollama pull llama3.2
"""

from crewai import Agent, Task, Crew, Process
from langchain_ollama import ChatOllama

# Use a local Ollama model
llm = ChatOllama(model="llama3.2", temperature=0.3)

# ---------- Agents ----------
researcher = Agent(
    role="Technical Researcher",
    goal="Gather accurate, concise technical facts about the given AI topic",
    backstory="You are an experienced AI researcher who finds the most relevant facts and papers.",
    llm=llm,
    verbose=True,
    allow_delegation=False,
)

writer = Agent(
    role="Technical Writer",
    goal="Write a clear, structured technical summary that engineering students can understand",
    backstory="You specialise in turning research notes into clean educational summaries.",
    llm=llm,
    verbose=True,
    allow_delegation=False,
)

critic = Agent(
    role="Technical Critic",
    goal="Review the summary for accuracy, clarity and completeness; suggest concrete improvements",
    backstory="You are a strict but fair senior engineer who catches missing points and vague statements.",
    llm=llm,
    verbose=True,
    allow_delegation=False,
)

# ---------- Tasks ----------
def build_tasks(topic: str):
    research_task = Task(
        description=f"Research the topic '{topic}'. List 4–6 key technical facts that a B.Tech student should know.",
        expected_output="A bullet list of key facts with short explanations.",
        agent=researcher,
    )

    write_task = Task(
        description=f"Using the research notes, write a short technical summary (150–250 words) about '{topic}' suitable for engineering students.",
        expected_output="A well-structured summary with an introduction, key points, and a short conclusion.",
        agent=writer,
        context=[research_task],
    )

    critique_task = Task(
        description="Review the summary. Point out any inaccuracies, missing important ideas, or unclear explanations. Then provide a short improved version.",
        expected_output="Critique points + a revised summary.",
        agent=critic,
        context=[write_task],
    )
    return [research_task, write_task, critique_task]


# ---------- Crew ----------
if __name__ == "__main__":
    topic = "Retrieval-Augmented Generation (RAG)"
    tasks = build_tasks(topic)

    crew = Crew(
        agents=[researcher, writer, critic],
        tasks=tasks,
        process=Process.sequential,
        verbose=True,
    )

    print(f"\nStarting multi-agent crew on topic: {topic}\n")
    result = crew.kickoff()
    print("\n" + "=" * 70)
    print("FINAL RESULT")
    print("=" * 70)
    print(result)
