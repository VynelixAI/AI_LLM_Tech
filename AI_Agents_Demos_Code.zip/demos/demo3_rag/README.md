# Demo 3 — Basic RAG Pipeline

## Goal
Build a simple Retrieval-Augmented Generation system that answers questions from your own documents.

## Two versions
1. **simple_rag.py** — Pure Python + sentence-transformers + FAISS (no LangChain)
2. **langchain_rag.py** — Clean LangChain version (recommended for learning modern patterns)

## Prerequisites
```bash
pip install sentence-transformers faiss-cpu langchain langchain-community langchain-ollama pypdf
# optional: ollama pull llama3.2
```

## How it works
1. Load documents (text files or PDFs)
2. Split into chunks
3. Create embeddings
4. Store in a vector index (FAISS)
5. At query time: retrieve top-k relevant chunks → stuff into prompt → LLM answers

## Quick start
```bash
# Put some .txt or .pdf files into the ./docs folder
mkdir -p docs
echo "Bengaluru is the capital of Karnataka. It is known as the Silicon Valley of India." > docs/bengaluru.txt

python simple_rag.py
# or
python langchain_rag.py
```
