"""
Demo 1 — Simple chat with a local Ollama model
Requires: ollama running + a model pulled (e.g. ollama pull llama3.2)
Install dependency: pip install requests
"""

import requests
import json

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.2"  # change to mistral, qwen2.5:7b, phi3, etc.


def chat(prompt: str, model: str = MODEL) -> str:
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.7,
            "top_p": 0.9,
        },
    }
    response = requests.post(OLLAMA_URL, json=payload, timeout=120)
    response.raise_for_status()
    data = response.json()
    return data.get("response", "").strip()


def stream_chat(prompt: str, model: str = MODEL):
    """Stream tokens as they are generated."""
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True,
    }
    with requests.post(OLLAMA_URL, json=payload, stream=True, timeout=120) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if line:
                chunk = json.loads(line)
                token = chunk.get("response", "")
                print(token, end="", flush=True)
                if chunk.get("done"):
                    print()
                    break


if __name__ == "__main__":
    print(f"Using model: {MODEL}")
    print("-" * 50)

    # Non-streaming example
    answer = chat("Explain the Transformer attention mechanism in 3 simple sentences.")
    print("Answer:\n", answer)
    print("-" * 50)

    # Streaming example
    print("Streaming answer:")
    stream_chat("Write a short Python function that computes Fibonacci numbers.")
