# Demo 1 — Run LLMs Locally with Ollama

## Goal
Install Ollama and chat with an open-source model in under 5 minutes. No GPU required for small models.

## Prerequisites
- Linux, macOS, or Windows
- ~4–8 GB free disk space (depending on model size)
- Internet connection for first download

## Steps

### 1. Install Ollama

**Linux / macOS:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

**Windows:**
Download the installer from https://ollama.com and run it.

### 2. Pull a model
```bash
ollama pull llama3.2          # ~2 GB, good general model
ollama pull mistral           # strong alternative
ollama pull qwen2.5:7b        # excellent reasoning
ollama pull phi3              # small & fast
```

### 3. Chat interactively
```bash
ollama run llama3.2
```
Type your prompt and press Enter. Type `/bye` to exit.

### 4. Use the local API
Ollama exposes an OpenAI-compatible API on `http://localhost:11434`.

Example with curl:
```bash
curl http://localhost:11434/api/generate -d '{
  "model": "llama3.2",
  "prompt": "Explain attention mechanism in one paragraph.",
  "stream": false
}'
```

### 5. Python example
See `chat_with_ollama.py` in this folder.

## Useful commands
```bash
ollama list                   # list downloaded models
ollama rm llama3.2            # remove a model
ollama show llama3.2          # model details
ollama serve                  # start the server (usually automatic)
```
