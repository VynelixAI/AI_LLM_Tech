"""
Demo 3a — Minimal RAG from scratch (no LangChain)

Uses:
  - sentence-transformers for embeddings
  - FAISS for vector search
  - Ollama (optional) or a simple extractive fallback
"""

import os
from pathlib import Path
from typing import List, Tuple

import numpy as np

try:
    from sentence_transformers import SentenceTransformer
    import faiss
except ImportError:
    print("Please install: pip install sentence-transformers faiss-cpu")
    raise

# Optional LLM via Ollama
try:
    import requests
    HAS_OLLAMA = True
except ImportError:
    HAS_OLLAMA = False


# ---------- 1. Load & chunk documents ----------
def load_documents(docs_dir: str = "docs") -> List[str]:
    texts = []
    path = Path(docs_dir)
    if not path.exists():
        path.mkdir(parents=True)
        sample = path / "sample.txt"
        sample.write_text(
            "Bengaluru (Bangalore) is the capital of the Indian state of Karnataka. "
            "It is widely regarded as the Silicon Valley of India because of its role of IT companies. "
            "The city has a population of approximately 14 million people. "
            "Famous landmarks include Lalbagh Botanical Garden, Cubbon Park, and the Vidhana Soudha."
        )
        print(f"Created sample document at {sample}")

    for f in path.glob("**/*"):
        if f.suffix.lower() in {".txt", ".md"}:
            texts.append(f.read_text(encoding="utf-8", errors="ignore"))
    return texts


def chunk_text(text: str, chunk_size: int = 200, overlap: int = 40) -> List[str]:
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i : i + chunk_size])
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks


# ---------- 2. Embeddings + FAISS index ----------
class SimpleRAG:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        print(f"Loading embedding model: {model_name}")
        self.embedder = SentenceTransformer(model_name)
        self.chunks: List[str] = []
        self.index = None

    def build(self, documents: List[str]):
        all_chunks = []
        for doc in documents:
            all_chunks.extend(chunk_text(doc))
        self.chunks = all_chunks
        print(f"Total chunks: {len(self.chunks)}")

        embeddings = self.embedder.encode(self.chunks, show_progress_bar=True)
        embeddings = np.array(embeddings).astype("float32")

        dim = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dim)
        self.index.add(embeddings)
        print("FAISS index built.")

    def retrieve(self, query: str, k: int = 3) -> List[Tuple[str, float]]:
        q_emb = self.embedder.encode([query]).astype("float32")
        distances, indices = self.index.search(q_emb, k)
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self.chunks):
                results.append((self.chunks[idx], float(dist)))
        return results

    def answer(self, query: str, k: int = 3, use_llm: bool = True) -> str:
        retrieved = self.retrieve(query, k=k)
        context = "\n\n".join([c for c, _ in retrieved])

        print("\n--- Retrieved chunks ---")
        for i, (chunk, dist) in enumerate(retrieved, 1):
            print(f"[{i}] (distance={dist:.3f}) {chunk[:120]}...")

        if use_llm and HAS_OLLAMA:
            return self._llm_answer(query, context)
        else:
            # Fallback: just return the most relevant chunk
            return retrieved[0][0] if retrieved else "No relevant information found."

    def _llm_answer(self, query: str, context: str) -> str:
        prompt = f"""Use only the following context to answer the question.
If the answer is not in the context, say "I don't know based on the provided documents."

Context:
{context}

Question: {query}

Answer:"""
        try:
            r = requests.post(
                "http://localhost:11434/api/generate",
                json={"model": "llama3.2", "prompt": prompt, "stream": False},
                timeout=60,
            )
            r.raise_for_status()
            return r.json().get("response", "").strip()
        except Exception as e:
            return f"(LLM unavailable: {e})\n\nMost relevant context:\n{context[:500]}"


if __name__ == "__main__":
    docs = load_documents("docs")
    rag = SimpleRAG()
    rag.build(docs)

    questions = [
        "What is Bengaluru known for?",
        "What is the approximate population of Bengaluru?",
        "Name two famous landmarks in the city.",
    ]

    for q in questions:
        print("\n" + "=" * 60)
        print("Q:", q)
        print("=" * 60)
        ans = rag.answer(q, use_llm=True)
        print("\nAnswer:\n", ans)
