"""
Demo 3b — RAG with LangChain + Ollama

Requires:
  pip install langchain langchain-community langchain-ollama sentence-transformers faiss-cpu
  ollama pull llama3.2
"""

from pathlib import Path
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser


def build_rag(docs_dir: str = "docs"):
    path = Path(docs_dir)
    if not path.exists():
        path.mkdir(parents=True)
        (path / "sample.txt").write_text(
            "Bengaluru (Bangalore) is the capital of Karnataka and is known as the "
            "Silicon Valley of India. The city has roughly 14 million residents. "
            "Popular places include Lalbagh, Cubbon Park, and Vidhana Soudha."
        )

    # 1. Load
    loader = DirectoryLoader(docs_dir, glob="**/*.txt", loader_cls=TextLoader)
    documents = loader.load()
    print(f"Loaded {len(documents)} document(s)")

    # 2. Split
    splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    chunks = splitter.split_documents(documents)
    print(f"Created {len(chunks)} chunks")

    # 3. Embed + store
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

    # 4. LLM
    llm = ChatOllama(model="llama3.2", temperature=0.1)

    # 5. Prompt + chain
    prompt = ChatPromptTemplate.from_template(
        """Answer the question using only the context below.
If the answer is not present, say "I don't know based on the provided documents."

Context:
{context}

Question: {question}

Answer:"""
    )

    def format_docs(docs):
        return "\n\n".join(d.page_content for d in docs)

    chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain


if __name__ == "__main__":
    rag_chain = build_rag("docs")

    questions = [
        "What is Bengaluru famous for?",
        "How many people live in Bengaluru?",
        "List some landmarks.",
    ]

    for q in questions:
        print("\n" + "=" * 60)
        print("Q:", q)
        print("=" * 60)
        answer = rag_chain.invoke(q)
        print(answer)
