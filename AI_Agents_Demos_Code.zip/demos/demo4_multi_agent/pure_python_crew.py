"""
Demo 4a — Multi-agent collaboration (pure Python, no external LLM)

Three agents work in sequence:
  1. Researcher  – gathers facts
  2. Writer      – turns facts into a short technical summary
  3. Critic      – reviews the summary and suggests improvements
"""

from typing import Dict, List


# ---------- Shared "knowledge base" (simulates search / memory) ----------
KNOWLEDGE = {
    "transformer": [
        "The Transformer architecture was introduced in the paper 'Attention Is All You Need' (Vaswani et al., 2017).",
        "It relies on self-attention instead of recurrence or convolution.",
        "Key components: multi-head attention, positional encoding, feed-forward networks, residual connections.",
        "Modern LLMs (GPT, Llama, Mistral) are decoder-only Transformers.",
    ],
    "rag": [
        "RAG stands for Retrieval-Augmented Generation.",
        "It retrieves relevant documents from a knowledge base and adds them to the LLM prompt.",
        "This reduces hallucination and allows the model to use up-to-date or private data.",
        "Typical pipeline: chunk → embed → store in vector DB → retrieve → generate.",
    ],
    "agents": [
        "An AI Agent uses an LLM as its reasoning core and can call external tools.",
        "The basic loop is: Perceive → Plan → Act → Observe → Update memory.",
        "Popular frameworks: LangChain, LlamaIndex, CrewAI, AutoGen.",
        "Multi-agent systems assign different roles (researcher, coder, critic) that collaborate.",
    ],
}


# ---------- Agent definitions ----------
class Researcher:
    def run(self, topic: str) -> List[str]:
        print(f"[Researcher] Gathering facts about '{topic}'...")
        key = topic.lower().strip()
        for k, facts in KNOWLEDGE.items():
            if k in key:
                print(f"[Researcher] Found {len(facts)} facts.")
                return facts
        return [f"No specific facts found for '{topic}'. Using general knowledge."]


class Writer:
    def run(self, topic: str, facts: List[str]) -> str:
        print(f"[Writer] Writing a short technical summary...")
        bullet_points = "\n".join(f"- {f}" for f in facts)
        summary = (
            f"Technical Summary: {topic.title()}\n\n"
            f"Key points:\n{bullet_points}\n\n"
            f"In short, {topic} is an important concept in modern AI systems "
            f"and is widely used in production applications."
        )
        return summary


class Critic:
    def run(self, summary: str) -> str:
        print(f"[Critic] Reviewing the summary...")
        issues = []
        if len(summary) < 100:
            issues.append("Summary is quite short; consider adding more depth.")
        if "2017" not in summary and "transformer" in summary.lower():
            issues.append("Missing the original publication year of the Transformer paper.")
        if not issues:
            issues.append("Looks solid. No major issues found.")

        critique = "Critique:\n" + "\n".join(f"• {i}" for i in issues)
        improved = (
            summary
            + "\n\n"
            + critique
            + "\n\nRevised note: Always cite primary sources and keep the summary focused on engineering relevance."
        )
        return improved


# ---------- Orchestrator (simple sequential crew) ----------
def run_crew(topic: str) -> str:
    print("=" * 60)
    print(f"CREW STARTING — Topic: {topic}")
    print("=" * 60)

    researcher = Researcher()
    writer = Writer()
    critic = Critic()

    facts = researcher.run(topic)
    summary = writer.run(topic, facts)
    final = critic.run(summary)

    print("\n" + "=" * 60)
    print("FINAL OUTPUT")
    print("=" * 60)
    print(final)
    return final


if __name__ == "__main__":
    run_crew("Transformer architecture")
    print("\n\n")
    run_crew("RAG")
    print("\n\n")
    run_crew("AI Agents")
