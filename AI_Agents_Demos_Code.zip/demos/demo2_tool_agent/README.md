# Demo 2 — Simple Tool-Calling Agent (ReAct style)

## Goal
Build a minimal agent that can decide when to use tools (calculator + mock search) and reason step-by-step.

## Two versions included
1. **pure_python_agent.py** — No external LLM required. Uses a rule-based mock LLM so you can run it offline and understand the loop.
2. **langchain_agent.py** — Real agent using LangChain + Ollama (or any OpenAI-compatible endpoint).

## Prerequisites
```bash
pip install langchain langchain-community langchain-ollama
# (optional) ollama pull llama3.2
```

## How to run
```bash
# Offline / learning version
python pure_python_agent.py

# Real LLM version (requires Ollama running)
python langchain_agent.py
```

## What you will see
The agent receives a goal, then produces a trajectory of:
Thought → Action → Observation → Thought → … → Final Answer
