"""
Demo 2b — Real tool-calling agent with LangChain + Ollama

Requires:
  pip install langchain langchain-community langchain-ollama
  ollama pull llama3.2   (or any model that supports tools reasonably well)
"""

from langchain_ollama import ChatOllama
from langchain_core.tools import tool
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate


# ---------- Define tools ----------
@tool
def calculator(expression: str) -> str:
    """Evaluate a mathematical expression. Input should be a valid Python arithmetic expression."""
    try:
        allowed = set("0123456789+-*/().% ")
        if not all(c in allowed for c in expression):
            return "Error: invalid characters"
        result = eval(expression.replace("%", "/100"), {"__builtins__": {}})
        return str(result)
    except Exception as e:
        return f"Error: {e}"


@tool
def mock_search(query: str) -> str:
    """Search for factual information. Useful for population, capitals, historical facts, etc."""
    knowledge = {
        "population of bengaluru": "Approximately 14 million (1.4 crore) in 2024-25.",
        "population of bangalore": "Approximately 14 million (1.4 crore) in 2024-25.",
        "capital of india": "New Delhi is the capital of India.",
        "python language": "Python was created by Guido van Rossum and released in 1991.",
    }
    q = query.lower()
    for key, value in knowledge.items():
        if key in q:
            return value
    return f"No reliable information found for '{query}'."


tools = [calculator, mock_search]


# ---------- LLM ----------
llm = ChatOllama(
    model="llama3.2",          # change if you pulled a different model
    temperature=0.1,
)


# ---------- Prompt ----------
prompt = ChatPromptTemplate.from_messages([
    ("system", 
     "You are a helpful reasoning agent. "
     "Use the available tools when needed. "
     "Think step by step. "
     "When you have enough information, give a clear final answer."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])


# ---------- Agent ----------
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, max_iterations=6)


if __name__ == "__main__":
    questions = [
        "What is 17% of the population of Bengaluru?",
        "What is the capital of India and what is 25 * 48?",
    ]

    for q in questions:
        print("\n" + "=" * 70)
        print("Question:", q)
        print("=" * 70)
        result = agent_executor.invoke({"input": q})
        print("\nFinal Answer:", result["output"])
